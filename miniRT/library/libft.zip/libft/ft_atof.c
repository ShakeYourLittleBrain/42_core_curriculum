/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atof.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: skhastag <skhastag@student.42heilbornn.de> +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/09 10:46:57 by skhastag          #+#    #+#             */
/*   Updated: 2024/07/09 10:49:39 by skhastag         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static float	ft_atof_helper(char *str, float result, float divider)
{
	while (*str >= '0' && *str <= '9')
	{
		result = result * 10 + (*str - '0');
		str++;
	}
	if (*str == '.')
	{
		str++;
		while (*str >= '0' && *str <= '9')
		{
			result = result + (*str - '0') / divider;
			divider *= 10;
			str++;
		}
	}
	return (result);
}

float	ft_atof(char *str)
{
	float	result;
	float	divider;
	int		sign;

	sign = 1;
	result = 0;
	divider = 10;
	while (*str == ' ')
		str++;
	if (*str == '-' || *str == '+')
	{
		if (*str == '-')
			sign = -1;
		str++;
	}
	result = ft_atof_helper(str, result, divider);
	return (result * sign);
}
