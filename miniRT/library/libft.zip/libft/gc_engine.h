/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   gc_engine.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: skhastag <skhastag@student.42heilbornn.de> +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/21 02:17:41 by skhastag          #+#    #+#             */
/*   Updated: 2024/07/21 20:58:01 by skhastag         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GC_ENGINE_H
# define GC_ENGINE_H

# include <stdlib.h>
# include <unistd.h>

typedef struct s_gc
{
	void		*ptr;
	struct s_gc	*next;
}				t_gc;

void			*ft_gc_malloc_check_and_add(t_gc **gc, size_t size);
int				ft_gc_add(t_gc **gc, void *ptr);
void			ft_gc_free(t_gc **gc);
int				ft_gc_size(t_gc *gc);
void			ft_gc_init(t_gc **gc);
t_gc			**get_gc(void);

#endif
