/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   gc_engine.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: skhastag <skhastag@student.42heilbornn.de> +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/21 02:17:17 by skhastag          #+#    #+#             */
/*   Updated: 2024/07/21 21:15:15 by skhastag         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "gc_engine.h"

void	ft_gc_init(t_gc **gc)
{
	*gc = (t_gc *)malloc(sizeof(t_gc));
	if (!*gc)
	{
		write(2, "Error: malloc failed\n", 21);
		exit(EXIT_FAILURE);
	}
	(*gc)->ptr = NULL;
	(*gc)->next = NULL;
}

int	ft_gc_size(t_gc *gc)
{
	int	size;

	size = 0;
	while (gc)
	{
		size++;
		gc = gc->next;
	}
	return (size);
}

int	ft_gc_add(t_gc **gc, void *ptr)
{
	t_gc	*new;

	new = (t_gc *)malloc(sizeof(t_gc));
	if (!new)
	{
		write(2, "Error: malloc failed\n", 21);
		ft_gc_free(gc);
		exit(EXIT_FAILURE);
	}
	new->ptr = ptr;
	new->next = *gc;
	*gc = new;
	return (1);
}

void	*ft_gc_malloc_check_and_add(t_gc **gc, size_t size)
{
	void	*ptr;

	ptr = malloc(size);
	if (!ptr)
	{
		write(2, "Error: malloc failed\n", 21);
		ft_gc_free(gc);
		exit(EXIT_FAILURE);
	}
	ft_gc_add(gc, ptr);
	return (ptr);
}

void	ft_gc_free(t_gc **gc)
{
	t_gc	*tmp;

	while (*gc)
	{
		tmp = *gc;
		*gc = (*gc)->next;
		free(tmp->ptr);
		free(tmp);
	}
	*gc = NULL;
}
